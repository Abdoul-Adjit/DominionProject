#include<iostream>
#include<vector>
#include "victoire.h"

int victoire::getCout(){
    return this-> cout;
}

int victoire::getValeur(){
    return this->valeur;
}