#include<iostream>
#include<vector>
#include "tresor.h"

int tresor::getCout(){
    return this-> cout;
}

int tresor::getValeur(){
    return this->valeur;
}