#ifndef PHASE_H
#define PHASE_H
enum class PhaseJeu { Action, Achat, Attente };

extern PhaseJeu phase;
#endif