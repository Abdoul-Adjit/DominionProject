#include<iostream>
#include<vector>
#include "workshop.h"

void workshop::play(Joueur* j, PlateauDeJeu* p){
    
};