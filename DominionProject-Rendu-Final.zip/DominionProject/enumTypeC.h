#ifndef TYPECARTE_H
#define TYPECARTE_H
enum class TypeCarte { Action, Money, Victory };

extern TypeCarte type;
#endif