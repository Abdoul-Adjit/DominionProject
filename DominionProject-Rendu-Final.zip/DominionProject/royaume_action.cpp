#include<iostream>
#include<vector>
#include "royaume_action.h"

int royaume_action::getactionBonus(){
    return this->actionBonus;
};
int royaume_action::getvictoryPointBonus(){
    return this->victoryPointBonus;
};
int royaume_action::getbuyBonus(){
    return this->buyBonus;
};
int royaume_action::getcardBonus(){
    return this->cardBonus;
};
int royaume_action::getmoneyBonus(){
    return this->moneyBonus;
};
